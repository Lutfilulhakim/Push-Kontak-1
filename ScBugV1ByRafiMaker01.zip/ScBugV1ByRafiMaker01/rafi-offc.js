/*
Sc by 𝐑𝐀𝐅𝐈 𝑪𝑹𝑨𝑺𝑯 𝐈𝐍𝐅𝐈𝐍𝐈𝐓𝐘
Base by Hw Mod And RafiMaker01

Rename ? Tag gw 
Reupload? Tag gw

*/


const fs = require('fs')
const chalk = require('chalk')

global.gr = 'https://chat.whatsapp.com/JbgIz0e5p6T65h5piy0UdC' // LinkNya bebas Luh mau Pake Link apa
global.ig = '@bangr_xd_shop' // ubah aja
global.email = 'tifannyalesya@gmail.com' //serah
global.region = 'jepang' // serah
//—————「 Set Nama Own & Bot 」—————//
global.ownername = 'RafiMaker01' //ubah jadi nama mu, note tanda ' gausah di hapus!
//=================================================//
global.owner = ['6288975467930'] // ubah aja pake nomor lu
//==========================BY RafiMaker01=======================//
global.keyopenai = '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'
//====================BY RafiMaker01=============================//
global.botname = 'Bot WhatsApp' //ubah jadi nama bot mu, note tanda ' gausah di hapus!
global.packname = '𝐑𝐀𝐅𝐈 𝑪𝑹𝑨𝑺𝑯 𝐈𝐍𝐅𝐈𝐍𝐈𝐓𝐘' // ubah aja ini nama sticker
global.author = '𝐑𝐀𝐅𝐈 𝑪𝑹𝑨𝑺𝑯 𝐈𝐍𝐅𝐈𝐍𝐈𝐓𝐘' // ubah aja ini nama sticker
global.prefa = ['','!','.',',','🐤','🗿']
global.sessionName = 'sesion' //Gausah Juga
global.sp = '⭔' // Gausah Juga
global.wlcm = []
global.wlcmm = []
global.anticall = false
//=================================================//
//Gausah Juga
global.limitawal = {
    premium: "Infinity",
    free: 100
}
//=================================================//
let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})